BOT_TOKEN = "8335733549:AAFMpqifzGVVAPb_IeTpWMy8IhvSiTZEsuo"
DB_PATH = "cooknet.db"
